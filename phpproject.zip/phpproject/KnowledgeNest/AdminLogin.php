<?php 

$username=$_POST["username"];
$password=$_POST["password"];

session_start();
   
if ($username=='meet' && $password=='meet'){
    $_SESSION['username']=$username;
    $_SESSION['password']=$password;
    header("location:AdminPanel.php");
    
} else {
    header("location:AdminLogin.html");
    
}



?>
