<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\Exception.php';
require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\PHPMailer.php';
require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\SMTP.php';


include ("config.php");

$name=$_POST["name"];
$uemail=$_POST["email"];
$reply=$_POST["reply"];
$query=$_POST["query"];
    $mail = new PHPMailer(true);
    
    $email = 'meetmistry96655@gmail.com';
    $password = 'npnz ktfg asex nnbp';
    
    try {
        // Configure SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $email;
        $mail->Password = $password;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 25;
    
        // Recipient information
        $mail->setFrom($email, 'KnowledgeNest');
        $mail->addAddress($uemail, $name);
        $mail->addReplyTo($email, 'KnowledgeNest');
    
        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Reply From KnowledgeNest';
        $mail->Body    = 
        ' <html>
        <head>
            <style>
                body {
                    font-family: "Times New Roman", Times, serif;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                }
                .header {
                    background-color: #17A2b8;
                    padding: 20px;
                    text-align: center;
                }
                .content {
                    padding: 20px;
                }
                .footer {
                    background-color: #17A2b8;
                    padding: 10px;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Reply From KnowledgeNest</h2>
                </div>
                <div class="content">
                    <p>Dear ' . $name . ',</p>
                    <p>We appreciate your inquiry and would like to provide you with a solution.</p>
                    <p>Your Query:</p>
                    <p><strong>' . $query . '</strong></p>
                    <p>Our response for your query:</p>
                    <p><strong>' . $reply . '</strong></p>
                    <p>Please feel free to reach out if you have any further questions or concerns.</p>
                    <p>This is an auto-generated email; please do not reply to this email.</p>
                </div>
                <div class="footer">
                    <p>Best regards,<br>KnowledgeNest Team</p>
                </div>
            </div>
        </body>
        </html>
    ';
    
        $mail->send();
        header("location:ContactManagement.php");

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
mysqli_close($conn);

?>
