<?php 
  $id=$_GET["id"];
  include('config.php');
  $sql="SELECT * FROM `contact` WHERE `id`=$id";
  $result=mysqli_query($conn,$sql);
  $rows=mysqli_fetch_assoc($result);
  mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Contact</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Handlee&family=Nunito&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet" />
  </head>

  <body>
    <div class="container-fluid bg-primary mb-5 shadow">
      <div
        class="d-flex flex-column align-items-center justify-content-center"
        style="min-height: 50px"
      >
        <h3 class="display-4 font-weight-large text-white">Reply Section</h3>
        <a href="ContactManagement.php" class="btn btn-primary px-4">
          << Back</a
        >
      </div>
    </div>
    <div class="row">
      <div class="col-lg-6 mx-auto mb-5">
        <div class="contact-form">
          <div id="success"></div>
          <form method="post" action="ReplyEmail.php">
            <div class="control-group">
              <input type="text" class="form-control" id="name" name="name"
              placeholder="Your Name" required="required" value= "<?php echo "{$rows['name']}"?>"
              data-validation-required-message="Please enter your name" />
              <p class="help-block text-danger"></p>
            </div>
            <div class="control-group">
              <input type="email" class="form-control" id="email" name="email"
              placeholder="Your Email" required="required" value= "<?php echo "{$rows['email']}"?>"
              data-validation-required-message="Please enter your email" />
              <p class="help-block text-danger"></p>
            </div>
            <div class="control-group">
              <input type="tel" class="form-control" id="phone" name="phone"
              placeholder="Phone Number" required="required" value= "<?php echo "{$rows['phone']}"?>"
              data-validation-required-message="Please enter your phone number"
              />
              <p class="help-block text-danger"></p>
            </div>
            <div class="control-group">
              <textarea
                class="form-control"
                rows="6"
                id="message"
                placeholder="Query"
                required="required"
                name="query"
                data-validation-required-message="Please enter your query"
              ><?php echo $rows['query']; ?></textarea
              >
              <p class="help-block text-danger"></p>
            </div>
            <div class="control-group">
              <textarea
                class="form-control"
                rows="6"
                id=""
                placeholder="Reply"
                required="required"
                name="reply"
                data-validation-required-message="Please enter your reply"
              ></textarea>
              <p class="help-block text-danger"></p>
            </div>
            <div>
              <button
                class="btn btn-primary py-2 px-4"
                type="submit"
                id="sendMessageButton"
              >
                Send Reply
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>
