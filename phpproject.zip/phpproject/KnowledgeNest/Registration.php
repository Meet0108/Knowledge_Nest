<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\Exception.php';
require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\PHPMailer.php';
require 'C:\xampp\htdocs\phpproject\KnowledgeNest\PHPMailer\src\SMTP.php';


include ("config.php");

$name=$_POST["name"];
$uemail=$_POST["email"];
$username=$_POST["username"];
$password1=$_POST["password"];

$sql = "INSERT INTO `user`(`id`, `name`, `email`, `username`, `password`) VALUES (NULL,'$name','$uemail','$username','$password1')";
$result=mysqli_query($conn,$sql);
if ($result) {
    $mail = new PHPMailer(true);
    
    $email = 'meetmistry96655@gmail.com';
    $password = 'npnz ktfg asex nnbp';
    
    try {
        // Configure SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $email;
        $mail->Password = $password;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 25;
    
        // Recipient information
        $mail->setFrom($email, 'KnowledgeNest');
        $mail->addAddress($uemail, $username);
        $mail->addReplyTo($email, 'KnowledgeNest');
    
        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'KnowledgeNest';
        $mail->Body    = '
        <html>
        <head>
            <style>
                body {
                    font-family: "Arial", sans-serif;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                }
                .header {
                    background-color: #17A2B8;
                    padding: 20px;
                    text-align: center;
                    color: #fff;
                }
                .content {
                    padding: 20px;
                }
                .footer {
                    background-color:  #17A2B8;
                    padding: 10px;
                    text-align: center;
                    color: #fff;
                
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Welcome to KnowledgeNest!</h2>
                </div>
                <div class="content">
                    <p>Dear ' . $name . ',</p>
                    <p>Thank you for registering with KnowledgeNest!</p>
                    <p>Your Login Details are:</p>
                    <p><strong>Username : '.$username.'</strong></p>
                    <p><strong>Password : '.$password1.'</strong></p>
                    <p>We are excited to have you as part of our community. Your account has been successfully created, and you can now explore all the amazing features and resources available on our website.</p>
                    
                    <p>This is an auto-generated email; please do not reply to this email.</p><br>
                    <p>Best Regards,</p>
                    <p>KnowledgeNest Team.</p>
                </div>
                <div class="footer">
                    <p>KnowledgeNest Team</p>
                </div>
            </div>
        </body>
        </html>
    ';
    
        $mail->send();
        echo 'Email sent successfully';

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

    header("location:Login.html");
} else {
    echo "error" . mysqli_error($conn);
}

mysqli_close($conn);

?>
