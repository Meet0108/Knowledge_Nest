
<?php 
session_start();
if (!isset($_SESSION['username']) && !isset($_SESSION['password'])) {
  header("location:AdminLogin.html");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>UserManagement</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Handlee&family=Nunito&display=swap"
      rel="stylesheet"
    />
    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet" />
  </head>

  <body>
    <div class="container-fluid bg-primary mb-5 shadow">
      <div
        class="d-flex flex-column align-items-center justify-content-center"
        style="min-height: 70px"
      >
        <h3 class="display-3 font-weight-large text-white">USERMANAGEMENT</h3>
        <a href="AdminPanel.php" class="btn btn-primary px-4"> << Back</a>
</div>
    </div>
    <div>
    <?php 
            include ('config.php');
            $sql = "SELECT * FROM `user` ";
            $result=mysqli_query($conn,$sql);
            

            if (mysqli_num_rows($result)>0) {
                echo "<div class='container-fluid'>
                <div class='table-responsive'>
                  <table class='table table-primary  table-striped'>
                    <thead>
                      <tr>
                        <th scope='col'>ID</th>
                        <th scope='col'>NAME</th>
                        <th scope='col'>EMAIL</th>
                        <th scope='col'>USERNAME</th>
                        <th scope='col'>PASSWORD</th>
                        <th scope='col'>DELETEUSER</th>
                      </tr>
                    </thead>
                    <tbody>
              ";



                while($rows=mysqli_fetch_assoc($result)){
                    echo "
            
            
                    <tr class=''>
                      <td scope='row'>{$rows['id']}</td>
                      <td>{$rows['name']}</td>
                      <td>{$rows['email']}</td>
                      <td>{$rows['username']}</td>
                      <td>{$rows['password']}
                      </td>
                      <td>
                        
                        <a name='' id='' class='btn btn-info' href='deleteuser.php?id={$rows['id']}' role='button'
                          >Delete</a
                        >
                      </td>
                    </tr>
            
            ";

                }
                
                echo "
            
                </tbody>
              </table>
            </div>
            </div>
            ";
                
            } else {
                echo "error". msyqli_error();
            }


            
            
            ?>
            


    </body>
</html>
