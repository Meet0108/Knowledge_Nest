<?php 
include ("config.php");
session_start();
$username=$_POST["username"];
$password=$_POST["password"];

    $sql = "SELECT * FROM `user` WHERE `username`='$username' and `password`='$password'";
    $result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result)>0) {
    $_SESSION['username']=$username;
    $_SESSION['password']=$password;
    header("location:index.php");
} else {
    echo "error" . mysqli_error($conn);
}

mysqli_close($conn);

?>
