<?php 
include ("config.php");

$id=$_GET["id"];

    $sql = "DELETE FROM `user` WHERE `id`=$id";
    $result=mysqli_query($conn,$sql);
if ($result) {
    header("location:UserManagement.php");
} else {
    echo "error" . mysqli_error($conn);
}

mysqli_close($conn);

?>
