<?php 
include('config.php');

$name=$_POST["name"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$query=$_POST["query"];

$sql="INSERT INTO `contact`(`id`, `name`, `email`, `phone`, `query`) VALUES (NULL,'$name','$email','$phone','$query')";
$result=mysqli_query($conn,$sql);

if ($result) {
    header("location:contactus.php");
} else {
    echo "error".mysqli_error();
}
?>